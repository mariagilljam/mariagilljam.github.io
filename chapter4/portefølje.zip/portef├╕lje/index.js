greenButton.addEventListener("click", function() {
    document.body.style.backgroundColor= "#cad2c5";
});
lightBrownButton.addEventListener("click", function() {
    document.body.style.backgroundColor= "#52796f";
});
brownButton.addEventListener("click", function() {
    document.body.style.backgroundColor= "#84a98c";
});
beigeButton.addEventListener("click", function() {
    document.body.style.backgroundColor= "#354f52";
});
lightGreenButton.addEventListener("click", function() {
    document.body.style.backgroundColor= "#2f4636";
});
